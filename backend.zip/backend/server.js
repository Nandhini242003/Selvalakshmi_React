import express from "express";
import cors from "cors";
import mysql from "mysql";

const app = express();
app.use(cors());
app.use(express.json());

// MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "uqdggrqf_sampletask_react",
  password: "#Hv=P%JtQ=2(WctC",
  database: "uqdggrqf_sampletask_react",
});

db.connect((err) => {
  if (err) {
    console.log("DB Connection Error:", err);
  } else {
    console.log("MySQL Connected");
  }
});

// LOGIN API
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  const sql = "SELECT * FROM users WHERE email = ? AND password = ?";
  db.query(sql, [email, password], (err, result) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: "Database error",
      });
    }

    if (result.length > 0) {
      return res.json({
        success: true,
        user: {
          id: result[0].id,
          name: result[0].name,
          email: result[0].email,
        },
      });
    } else {
      return res.json({
        success: false,
        message: "Invalid email or password",
      });
    }
  });
});

// Test route
app.get("/", (req, res) => {
  res.send("Backend running");
});

app.listen(3001, () => {
  console.log("Server is running on port 3001");
});
